<?php

return [

    'url'=>'htp://163.172.104.238/goomla/api'
]
?>