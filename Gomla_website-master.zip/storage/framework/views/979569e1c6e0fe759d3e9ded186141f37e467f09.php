<div class="mobile-menu-area hidden-lg hidden-md">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="mobile-menu">
                    <nav id="dropdown">
                        <ul >
                            <li><a href="<?php echo e(url('/')); ?>">الرئيسة</a></li>
                            <li class="mega-parent"><a href="<?php echo e(url('categories')); ?>">الاقسام</a>
                                <div class="mega-menu-area clearfix">
                                    <div class="mega-menu-link f-left">
                                        <?php
                                        $categories = json_decode(file_get_contents('http://163.172.33.245/goomla/api/categories'), true);
                                        $allCategories = array_chunk($categories, 5);
                                        ?>
                                        <?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pieces): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <ul class="single-mega-item">
                                                <?php $__currentLoopData = $pieces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($cate['hasSubCategories'] != null): ?>
                                                        <li><a href="<?php echo e(url('categories/'.$cate['id'])); ?>" title="<?php echo e($cate['name']); ?>"><?php echo e($cate['name']); ?></a></li>
                                                    <?php else: ?>
                                                        <li><a href="<?php echo e(url('products/'.$cate['id'])); ?>" title="<?php echo e($cate['name']); ?>"><?php echo e($cate['name']); ?></a></li>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </li>
                            <li><a href="<?php echo e(url('/about-us')); ?>">من نحن</a>
                            </li>
                            <li><a href="<?php echo e(url('/contact-us')); ?>">تواصل معنا</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>