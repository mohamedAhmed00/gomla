<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Body main wrapper start -->
<div class="wrapper">
    <!-- START HEADER AREA -->
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- BREADCRUMBS SETCTION START -->
        <div class="breadcrumbs-section plr-200 mb-80">
            <div class="breadcrumbs overlay-bg" style="background: #f6f6f6 url('<?php echo e(asset("gomla/images/coverphoto.jpg")); ?>') no-repeat scroll center center">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="breadcrumbs-inner">
                                <h1 class="breadcrumbs-title">المفضلة</h1>
                                <ul class="breadcrumb-list">
                                <li><a href="<?php echo e(url('/')); ?>">الرئيسية</a></li>
                                    <li>المفضلة</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- BREADCRUMBS SETCTION END -->
        <style>
                .breadcrumbs-inner .breadcrumbs-title,.breadcrumb-list li a,.breadcrumb-list li
            {
                color:#fff !important
            }
            .overlay-bg:before {
                background: none
            }
            .breadcrumb-list > li::before {
            color: #FFF
            }
            .product-remove .add
            {
                color:#000
            }
            .btn-danger
            {
                color: #fff !important;
                background-color: #ff7f00 !important;
                border-color: #ff7f00 !important;
            }
    </style>
        <!-- Start page content -->
        <section id="page-content" class="page-wrapper">

            <!-- SHOP SECTION START -->
            <div class="shop-section mb-80">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <!-- shopping-cart start -->
                                <!-- shopping-cart end -->
                                <!-- wishlist start -->
                                <div class="tab-pane active" id="wishlist">
                                    <div class="wishlist-content">
                                        <form action="#">
                                            <div class="table-content table-responsive mb-50">
                                                <table class="text-center">
                                                    <thead>
                                                    <tr>
                                                        <th class="product-thumbnail">المنتج</th>
                                                        <th class="product-thumbnail">الصورة</th>
                                                        <th class="product-price">السعر</th>
                                                        <th class="product-price">اضافه الي السلة</th>
                                                        <th class="product-remove">حذف</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php if(isset($xproducts)): ?>
                                                        <?php $__currentLoopData = $xproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr id=even"<?php echo e($product->id); ?>" class="first odd">
                                                                <td class="product-thumbnail">
                                                                    <div class="pro-thumbnail-info text-right">
                                                                        <a href="<?php echo e(url('product/'.$product->id)); ?>"><?php echo e($product->name); ?></a>
                                                                    </div>
                                                                </td>
                                                                <td class="product-thumbnail">
                                                                    <div class="pro-thumbnail-img">
                                                                        <?php if(isset($product->image)): ?>

                                                                            <img class="imagetable"
                                                                                 src="http://163.172.33.245/goomla/storage/app/erpnext/<?php echo e($product->image); ?>"
                                                                                 width="80" height="80"
                                                                                 alt="Slim Fit Casual Shirt">
                                                                        <?php else: ?>
                                                                            <img class="imagetable"
                                                                                 src="<?php echo e(url('/public/gomla/')); ?>/images/404.png"
                                                                                 alt="<?php echo e($product->name); ?>">

                                                                        <?php endif; ?>
                                                                    </div>
                                                                </td>
                                                                <td class="product-price"><?php echo e($product->standard_rate); ?>جنيه</td>
                                                                <td class="product-remove">
                                                                    <a title="Add to cart" class="add" style="cursor: pointer;" onclick="addToCart('<?php echo e($product->id); ?>','1')" id="hpaddtocart1<?php echo e($product->id); ?>"><i class="zmdi zmdi-shopping-cart-plus"></i></a>
                                                                </td>
                                                                <form action="<?php echo e(url('deletewishlist')); ?>" method="post">
                                                                    <?php echo e(csrf_field()); ?>

                                                                    <td class="product-remove">
                                                                        <input type="hidden" name="wishlist" value="wishlist">


                                                                        <input min="<?php echo e($product->min_order_qty); ?>"
                                                                               data-parsley-max="10"
                                                                               data-parsley-required="true"
                                                                               type="hidden"
                                                                               name="qty<?php echo e($product->id); ?>"
                                                                               id="<?php echo e($product->id); ?>"
                                                                               title="Quantity:">

                                                                        <input value="<?php echo e($product->name); ?>"
                                                                               data-parsley-required="true"
                                                                               type="hidden"
                                                                               name="name<?php echo e($product->id); ?>"
                                                                               id="name<?php echo e($product->id); ?>"
                                                                               title="Quantity:"
                                                                               class="input-text name">

                                                                        <input value="<?php echo e($product->id); ?>"
                                                                               data-parsley-required="true"
                                                                               type="hidden"
                                                                               name="id"
                                                                               id="code<?php echo e($product->id); ?>"
                                                                               title="item_code"
                                                                               class="input-text item_code">


                                                                        <button class="btn-danger" title="حذف من قائمه المفضله"
                                                                                type="submit"
                                                                                id="removewish<?php echo e($product->id); ?>">
                                                                            <i class="zmdi zmdi-close" aria-hidden="true">
                                                                            </i>
                                                                        </button>


                                                                    </td>
                                                                </form>

                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                                <!-- order-complete end -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- SHOP SECTION END -->

        </section>
        <!-- End page content -->

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--style-customizer end -->
</div>
<!-- Body main wrapper end -->

<div class="modal fade" id="exampleModalLong" style="top:100px" tabindex="-1" role="dialog"
     aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" id="homeSkipLoginBtn">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h5 class="modal-title" id="exampleModalLongTitle">تسجيل الدخول</h5>

            </div>
            <div class="modal-body">
                <div id="responseDone-erorr" class="">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        إغلاق
                    </button>
                    <a type="button" href="<?php echo e(url('/login')); ?>" class=" btn-danger">تسجيل الدخول</a>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog"
         aria-labelledby="mySmallModalLabel">
        <div id="responseDone-erorr" class="modal-dialog modal-sm" role="document">

        </div>
    </div>
</div>

<!-- Placed JS at the end of the document so the pages load faster -->
<?php echo $__env->make('layouts.endpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>