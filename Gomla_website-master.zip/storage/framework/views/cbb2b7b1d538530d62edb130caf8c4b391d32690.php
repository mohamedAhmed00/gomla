<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Gomla || Shop</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/icon/favicon.png">

    <!-- All CSS Files -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="<?php echo e(asset('gomla/css/bootstrap.min.css')); ?>">
    <!-- Nivo-slider css -->
    <link rel="stylesheet" href="<?php echo e(asset('gomla/lib/css/nivo-slider.css')); ?>">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="<?php echo e(asset('gomla/css/core.css')); ?>">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="<?php echo e(asset('gomla/css/shortcode/shortcodes.css')); ?>">
    <!-- Theme main style -->
    <link rel="stylesheet" href="<?php echo e(asset('gomla/css/style.css')); ?>">
    <!-- Responsive css -->
    <link rel="stylesheet" href="<?php echo e(asset('gomla/css/responsive.css')); ?>">
    <!-- User style -->
    <link rel="stylesheet" href="<?php echo e(asset('gomla/css/custom.css')); ?>">

    <!-- Style customizer (Remove these two lines please) -->
    <link rel="stylesheet" href="<?php echo e(asset('gomla/css/style-customizer.css')); ?>">
    <link href="#" data-style="styles" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Amiri" rel="stylesheet">
    <!-- Modernizr JS -->
    <script src="<?php echo e(asset('gomla/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>
</head>

<body style="font-family: 'Amiri'">