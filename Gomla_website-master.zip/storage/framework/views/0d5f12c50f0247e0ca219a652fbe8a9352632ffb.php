<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Body main wrapper start -->
<div class="wrapper">
    <!-- START HEADER AREA -->
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- BREADCRUMBS SETCTION START -->
        <div class="breadcrumbs-section plr-200 mb-80">
            <div class="breadcrumbs overlay-bg" style="background: #f6f6f6 url('<?php echo e(asset("gomla/images/coverphoto.jpg")); ?>') no-repeat scroll center center">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="breadcrumbs-inner">
                                <h1 class="breadcrumbs-title">حسابي الشخصي</h1>
                                <ul class="breadcrumb-list">
                                    <li><a href="index.html">الرئيسية</a></li>
                                    <li>حسابي الشخصي</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- BREADCRUMBS SETCTION END -->
        <!-- Start page content -->
        <div id="page-content" class="page-wrapper">

            <!-- LOGIN SECTION START -->
            <div class="login-section mb-80">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <div class="my-account-content" id="accordion2">
                                <!-- My Personal Information -->
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion2" href="#personal_info">بياناتي الشخصية</a>
                                        </h4>
                                    </div>
                                    <div class="main-container col2-right-layout">
        <div class="main">
            <div class="row">

                <section style="float: left !important;"
                         class="left-osama col-main col-sm-9 wow bounceInUp animated animated">
                    <ol class="one-page-checkout" id="checkoutSteps">
                        <li id="opc-billing" class="section allow active">
                            <div class="step-title">
                                
                            </div>
                            <div id="checkout-step-billing" class="step a-item">

                                <form id="co-billing-form" action="">
                                    <fieldset class="group-select">
                                        <ul class="">
                                            <li id="billing-new-address-form">
                                                <fieldset>
                                                    <ul>
                                                        <li class="wide">
                                                            <label class="bold"  for="billing:street1"> الإسم<em
                                                                        class="required"></em></label><br>

                                                            <input disabled type="text"
                                                                   value="<?php echo e($userData->user->name); ?>"
                                                                   title="الإسم" value=""
                                                                   class="input-text  required-entry">

                                                        </li>

                                                        <li class="wide">
                                                            <label class="bold" for="billing:street1"> البريد الإلكتروني<em
                                                                        class="required"></em></label><br>

                                                            <input disabled type="text"
                                                                   value="<?php echo e($userData->user->email); ?>"
                                                                   title="البريد الإلكتروني"
                                                                   class="input-text  required-entry">

                                                        </li>

                                                        <li class="wide">
                                                            <label class="bold" for="billing:street1"> رقم الموبايل<em
                                                                        class="required"></em></label><br>

                                                            <input disabled type="text"
                                                                   value="<?php echo e($userData->user->phone); ?>"
                                                                   title=" رقم الموبايل"
                                                                   class="input-text  required-entry">

                                                        </li>

                                                        <li class="fields">
                                                            <div class="input-box">
                                                            </div>
                                                        </li>


                                                        <label class="bold" for="billing:street1"> العنوان<em
                                                                    class="required"></em></label><br>
                                                        
                                                        <?php $__currentLoopData = $userData->address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <li class="wide">

                                                                <div  class="input-text required-entry">
                                                                    <?php echo e($address->title); ?><br>
                                                                    <?php echo e($address->building_no); ?> <?php echo e($address->street); ?>

                                                                    , <?php echo e($address->regoin); ?>,
                                                                    <?php echo e($address->city); ?> <br><?php echo e($address->nearest_landmark); ?><br> <?php echo e($address->apartment_no); ?><br> <?php echo e($address->floor_no); ?>



                                                                    </div>
                                                            </li>





                                                            <li class="wide">

                                                                <div style="height: 15px" type="text"
                                                                     title="Street Address 2"
                                                                     class="">

                                                                </div>

                                                            </li>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        

                                                        <li class="fields">


                                                        </li>

                                                    </ul>

                                                </fieldset>
                                            </li>

                                        </ul>

                                    </fieldset>
                                </form>

                            </div>
                        </li>

                    </ol>

                    <br>
                </section>

                <aside style="float: right !important;" class="col-right sidebar col-sm-3 wow bounceInUp animated animated">
                    <div id="checkout-progress-wrapper">
                        <div class="block block-progress">
                            <div class="block-title">
                                حسابي
                            </div>
                            <div class="block-content">
                                <dl>
                                    <div class="row">
                                        <div class="right" id="billing-progress-opcheckout">
                                            <dt class="">
                                                <a href="<?php echo e(url('wishlist')); ?>">المفضله</a>

                                            </dt>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="right" id="billing-progress-opcheckout">
                                            <dt class="">
                                                <a href="<?php echo e(url('cart')); ?>">سله الشراء</a>

                                            </dt>
                                        </div>
                                    </div>


                                    <div class="row">
                                        <div class="right" id="billing-progress-opcheckout">
                                            <dt class="">
                                                <a href="<?php echo e(url('history')); ?>">مشترياتي السابقه</a>

                                            </dt>
                                        </div>
                                    </div>

                                </dl>
                            </div>
                        </div>
                    </div>
                </aside> <!--col-right sidebar-->
            </div><!--row-->
        </div><!--main-container-inner-->
    </div> <!--main-container col2-left-layout-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- LOGIN SECTION END -->
        </div>
        <!-- End page content -->
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--style-customizer end -->
</div>
<!-- Body main wrapper end -->


<!-- Placed JS at the end of the document so the pages load faster -->
<?php echo $__env->make('layouts.endpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>