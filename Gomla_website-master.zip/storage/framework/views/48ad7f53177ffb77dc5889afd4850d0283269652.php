<script src="<?php echo e(asset('gomla/js/vendor/jquery-3.1.1.min.js')); ?>"></script>
<!-- Bootstrap framework js -->
<script src="<?php echo e(asset('gomla/js/bootstrap.min.js')); ?>"></script>
<!-- jquery.nivo.slider js -->
<script src="<?php echo e(asset('gomla/lib/js/jquery.nivo.slider.js')); ?>"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCDacJcoyPCr-jdlP9HK93h3YKNyf710J0"></script>
<script src="<?php echo e(asset('gomla/js/map.js')); ?>"></script>
<!-- All js plugins included in this file. -->
<script src="<?php echo e(asset('gomla/js/plugins.js')); ?>"></script>
<!-- Main js file that contents all jQuery plugins activation. -->
<script src="<?php echo e(asset('gomla/js/main.js')); ?>"></script>
<script>
    function view(title,price,img,desc,button){
        $('#productModal').modal('show');
        $("#modal_img").attr('src',img);
        $("#modal_desc").html(desc);
        $("#modal_header_title").text(title);
        $("#modal_button").html(button);
        $("#modelPrice").text(price + " " + "جنية ");
    }

</script>


<script type="text/javascript" src="<?php echo e(asset('js/parsley.js')); ?>"></script>
<script type="text/javascript">


    $('form').parsley();

    var loadingimg = "<?php echo e(asset('images/loading5.gif')); ?>";
    $('#register').one('click', function () {

        $('#loading-img').html('<img style="height:100px;" src="' + loadingimg + '" />');
//            jQuery('#loading-img').hide(10000);


        $('form').submit(function (e) {
            e.preventDefault(e);

            $.ajax({
                url: "<?php echo e(URL::to('register')); ?>",
                crossDomain: true,
                contentType: 'application/json',
                type: 'POST',
                data: JSON.stringify({
                    'name': $('input[name=name]').val(),
                    'email': $('input[name=UserEmail]').val(),
                    'phone': $('input[name=phone]').val(),
                    'address_phone': $('input[name=phone]').val(),
                    'password': $('input[name=UserPassword]').val(),
                    'floor_number': $('select[name=floor_number]').val(),
                    'apartment_number': $('input[name=apartment_number]').val(),
                    'building_number': $('input[name=building_number]').val(),
                    'street': $('input[name=street]').val(),
                    'nearest_landmark': $('input[name=nearest_landmark]').val(),
                    'region': $('select[name=region]').val(),
                    'city': "القاهره",
                    'lat': $('input[name=lat]').val(),
                    'lng': $('input[name=lng]').val(),
                    'address_title': $('input[name=address_title]').val(),
                    '_token': $('input[name=_token]').val()
                }),
                success: function (response) {
                    if (response == 1) {
                        $("#responseDone").html('<p>' + "تم التسجيل بنجاح" + '</p>');
                        window.scrollTo(0, 0);
                        $('.bs-example-modal-sm').modal('show');
                        $('#loading-img').hide();
                        window.setTimeout(function () {
                            window.location.href = '<?php echo e(url('/')); ?>';
                        }, 1000);

                    } else {

                        $("#responseDone").html('<p>' + response+ '</p>');
                        $("#responseDone p").css('color','red');
                        window.scrollTo(0, 0);

                        $('.bs-example-modal-sm').modal('show');
                        $('#loading-img').hide();
                    }


                },
                error: function (response) {
                    $("#responseDone").html('<p>' + response + '</p>');
                    $("#responseDone p").css('color','red');
                    window.scrollTo(0, 0);
                    $('.bs-example-modal-sm').modal('show');


                }
                ,
            });
        });
    })
    ;
</script>
<script>
    // Log LOGIN_NORMAL to Google Analytics
    var loginForm = document.getElementById('loginForm');
    loginForm.addEventListener('submit', function(event) {
        // Sends the event to Google Analytics
        gtag('event', 'LOGIN_NORMAL', {
            'event_category': 'LOGIN_SCREEN',
            'event_action': 'LOGIN_NORMAL'
        } )
    });

    // Log LOGIN_NORMAL to Google Analytics
    var facebookLogin = document.getElementById('Facebook');
    facebookLogin.addEventListener('click', function(event) {
        // Sends the event to Google Analytics
        gtag('event', 'LOGIN_FACEBOOK', {
            'event_category': 'LOGIN_SCREEN',
            'event_action': 'LOGIN_FACEBOOK'
        } )
    });
</script>
<script>
    // Log LOGIN_SKIP to Google Analytics
    var skipLogin = document.getElementById('homeSkipLoginBtn');
    skipLogin.addEventListener('click', function (event) {
        // Sends the event to Google Analytics
        gtag('event', 'LOGIN_SKIP', {
            'event_category': 'HOME_SCREEN',
            'event_action': 'LOGIN_SKIP'
        })
    });
</script>
<script>
    $( "#slider-range" ).slider({
        range: true,
        min: 5,
        max: 700,
        values: [ 5, 700 ],
        slide: function( event, ui ) {
            $( "#amount" ).val( "" + ui.values[ 0 ] + "-" + ui.values[ 1 ] );
        }
    });
    $( "#amount" ).val(  $( "#slider-range" ).slider( "values", 0 ) +
        "-" + $( "#slider-range" ).slider( "values", 1 ) );
$("#slider-range").mouseleave(function(){
    $.ajax({
        type:'POST',
        url:'/price',
        data:{
            "_token": "<?php echo e(csrf_token()); ?>",
            'value':$( "#amount" ).val(),
            'cate': "<?php echo e(Request::url()); ?>"
        },
        success:function(data){
            $("#data").html(data.data);
        }
    });
});
</script>
<script>
    function wishlist(id,name){
        $.ajax({
            type:'POST',
            url:'<?php echo e(url('addwishlist')); ?>',
            data:{
                "_token": "<?php echo e(csrf_token()); ?>",
                'id': id,
                'name': name
            },
            success:function(data){
                if (data == 2) {
                    $("#responseDone-erorr").html('<p style="color: red" >' + "يجب عليك تسجيل الدخول اولاً" + '</p>');
                    $('#exampleModalLong').modal('show');
                }
                else if (data.num == 1) {
                    $('#wishlist_count').html(data.count);
                    $('#addtofav1'+id).css("color", "red");
                } else {
                    $('#addtofav1'+id).css("color", "black");
                }
            }
        });
    }
function addToCart(id,qty) {
    $.ajax({
        type:'POST',
        url:'<?php echo e(url('addcart')); ?>',
        crossDomain: true,
        contentType: 'application/json',
        data:JSON.stringify({
            "_token": "<?php echo e(csrf_token()); ?>",
            'id': id,
            'qty': qty
        }),
        success:function(data){
            if (data == 1) {
                $("#responseDone-erorr").html('<p style="color: red" >' + "يجب عليك تسجيل الدخول اولاً" + '</p>');
                $('#exampleModalLong').modal('show');
            } else {
                $(".cart-quantity").html(data.count);
                $("#cart").html(data.cart);
                // $('#cart-sidebar').html('');
                // $("#responseDone").html('<p>' + "تم اضافة المنتج بنجاح" + '</p>');
                // $('.bs-example-modal-sm').modal('show');
                // $("#countapp1").html(data.length);
                // $("#countapp").html(data.length);
                // getCart(response);
            }
        }
    });
}
function addItemToCart(id) {
        var qty = $("#french-hens").val();
    $.ajax({
        type:'POST',
        url:'<?php echo e(url('addcart')); ?>',
        crossDomain: true,
        contentType: 'application/json',
        data:JSON.stringify({
            "_token": "<?php echo e(csrf_token()); ?>",
            'id': id,
            'qty': qty
        }),
        success:function(data){
            if (data == 1) {
                $("#responseDone-erorr").html('<p style="color: red" >' + "يجب عليك تسجيل الدخول اولاً" + '</p>');
                $('#exampleModalLong').modal('show');

            } else {
                $('#productModal').modal('hide');
                $(".cart-quantity").html(data.count);
                $("#cart").html(data.cart);
                // $('#cart-sidebar').html('');
                $("#responseDone").html('<p>' + "تم اضافة المنتج بنجاح" + '</p>');
                $('.bs-example-modal-sm').modal('show');

                // getCart(response);


            }
        }
    });
}
</script>
</body>

</html>