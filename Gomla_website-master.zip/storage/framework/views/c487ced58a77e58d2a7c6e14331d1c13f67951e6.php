<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Gomla || Shop</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/icon/favicon.png">

    <!-- All CSS Files -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <!-- Nivo-slider css -->
    <link rel="stylesheet" href="<?php echo e(asset('gomla/lib/css/nivo-slider.css')); ?>">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="<?php echo e(asset('gomla/css/core.css')); ?>">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="<?php echo e(asset('gomla/css/shortcode/shortcodes.css')); ?>">
    <!-- Theme main style -->
    <link rel="stylesheet" href="<?php echo e(asset('gomla/css/style.css')); ?>">
    <!-- Responsive css -->
    <link rel="stylesheet" href="<?php echo e(asset('gomla/css/responsive.css')); ?>">
    <!-- User style -->
    <link rel="stylesheet" href="<?php echo e(asset('gomla/css/custom.css')); ?>">

    <!-- Style customizer (Remove these two lines please) -->
    <link rel="stylesheet" href="<?php echo e(asset('gomla/css/style-customizer.css')); ?>">
    <link href="#" data-style="styles" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Amiri" rel="stylesheet">
    <!-- Modernizr JS -->
    <script src="<?php echo e(asset('gomla/js/vendor/modernizr-2.8.3.min.js')); ?>"></script>
</head>

<body style="font-family: 'Amiri'">

<!-- Body main wrapper start -->
<div class="wrapper">
    <!-- START HEADER AREA -->
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- BREADCRUMBS SETCTION START -->
    <div class="breadcrumbs-section plr-200 mb-80">
        <div class="breadcrumbs overlay-bg"
             style="background: #f6f6f6 url('<?php echo e(asset('gomla/images/coverphoto.jpg')); ?>') no-repeat scroll center center">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="breadcrumbs-inner">
                            <h1 class="breadcrumbs-title" style="color:#000"><a href="<?php echo e(url("/")); ?>"
                                                                                title="الذهاب إلي الرئيسيه">الرئيسية</a>
                            </h1>
                            <h1 class="breadcrumbs-title" style="color:#000;padding-top: 10px;padding-bottom: 30px">
                                <?php if(isset($catNames) && isset($catNames->mainCat)): ?>
                                    <a href="<?php echo e(url('categories/'.$catNames->mainCat->id)); ?>"><h2
                                                style="color:#000"><?php echo e($catNames->mainCat->name); ?></h2></a>

                                <?php endif; ?>
                            </h1>

                        </div>
                        <div class="page-title">


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- BREADCRUMBS SETCTION END -->
    <!-- Start page content -->
    <section id="page-content" class="page-wrapper">
        <style>
            .pagination
            {
                padding: 10px;
                box-shadow: 0 0 4px rgba(0, 0, 0, 0.1);
                text-align: center;
                width: 100%;
                margin-left: 10%;
            }
            .pagination .page-item {
                display: inline-block;
                margin-right: 3px;
            }
            .pagination .page-item .page-link
            {
                border: 1px solid #eee;
                color: #999999;
                display: block;
                font-family: roboto;
                font-size: 13px;
                font-weight: 400;
                height: 40px;
                line-height: 28px;
                text-align: center;
                width: 40px;
            }
            .pagination .active .page-link , .pagination .page-item:hover a ,.pagination .active:hover .page-link {
                border-color: #ff7f00;
                background-color: #ff7f00;
                color:#ccc
            }
            .pagination .active .page-link
            {
                background-color: #ff7f00;
                color:#ccc
            }
        </style>
        <!-- SHOP SECTION START -->
        <div class="shop-section mb-80">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 col-xs-12">
                        <div class="shop-content">
                            <!-- Tab Content start -->
                            <div class="tab-content">
                                <!-- grid-view -->
                                <div role="tabpanel" class="tab-pane active" id="grid-view">
                                    <script src="<?php echo e(asset('gomla/js/vendor/jquery-3.1.1.min.js')); ?>"></script>
                                    <!-- Bootstrap framework js -->
                                    <script src="<?php echo e(asset('gomla/js/bootstrap.min.js')); ?>"></script>
                                    <div class="row" id="data">

                                        <!-- product-item start -->
                                        <?php $products = $pageproducts->all() ?>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-4 col-sm-4 col-xs-12">
                                                <div class="product-item product-item-2">
                                                    <div class="product-img">
                                                        <a href="<?php echo e(url('product/'.$product->id)); ?>"
                                                           title="<?php echo e($product->name); ?>">
                                                            <?php if(isset($product->image)): ?>
                                                                <img src="http://163.172.33.245/goomla/storage/app/erpnext/<?php echo e($product->image); ?>"
                                                                     style="height: 300px" alt="<?php echo e($product->name); ?>">
                                                            <?php else: ?>
                                                                <img src="<?php echo e(asset('gomla/images/blog-banner.png')); ?>"
                                                                     alt="<?php echo e($product->name); ?>" style="height: 300px">
                                                            <?php endif; ?>
                                                        </a>
                                                    </div>
                                                    <div class="product-info">
                                                        <h6 class="product-title">
                                                            <a href="<?php echo e(url('product/'.$product->id)); ?>"
                                                               title="<?php echo e($product->name); ?>"><?php echo e($product->name); ?></a>
                                                        </h6>
                                                        <h6 class="brand-name"><?php echo e($product->brand); ?></h6>
                                                        <h3 class="pro-price"><?php echo e(number_format ($product->standard_rate , 2, '.', ',')); ?>

                                                            جنيه</h3>
                                                    </div>
                                                    <ul class="action-button">
                                                        <li>
                                                            <?php if(in_array($product->id, $wishlist_products)): ?>
                                                                <button class="link-wishlist"
                                                                        title="إضافة ألى قائمة المفضله"
                                                                        type="submit"
                                                                        style="color: red"
                                                                        id="addtofav<?php echo e($product->id); ?>">
                                                                    <span><a title="Wishlist"><i
                                                                                    class="zmdi zmdi-favorite"></i></a></span>
                                                                </button>
                                                            <?php else: ?>

                                                                <button class="link-wishlist"
                                                                        title="Add to Wishlist"
                                                                        type="submit"
                                                                        id="addtofav<?php echo e($product->id); ?>">
                                                                    <span><a title="Wishlist"><i
                                                                                    class="zmdi zmdi-favorite"></i></a></span>
                                                                </button>

                                                            <?php endif; ?>
                                                            
                                                        </li>
                                                        <li>
                                                            <a href="#" data-toggle="modal" data-target="#productModal"
                                                               title="Quickview"><i class="zmdi zmdi-zoom-in"></i></a>
                                                        </li>
                                                        <li>
                                                            <a href="#" title="Add to cart"><i
                                                                        class="zmdi zmdi-shopping-cart-plus"></i></a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <script>
                                                jQuery(document).ready(function () {
                                                    jQuery('#addtofav<?php echo e($product->id); ?>').click(function () {

                                                        jQuery.ajax({
                                                            url: "<?php echo e(url('/addwishlist')); ?>",
                                                            type: 'post',
                                                            data: {
                                                                'id': jQuery('input[name=fav_id<?php echo e($product->id); ?>]').val(),
                                                                'name': jQuery('input[name=favname<?php echo e($product->id); ?>]').val(),
                                                                '_token': jQuery('input[name=_token]').val()
                                                            },

                                                            success: function (response) {
                                                                if (response == 2) {
                                                                    jQuery("#responseDone-erorr").html('<p style="color: red" >' + "يجب عليك تسجيل الدخول اولاً" + '</p>');
                                                                    jQuery('#exampleModalLong').modal('show');
                                                                }
                                                                else if (response == 1) {
                                                                    jQuery('#addtofav<?php echo e($product->id); ?>').css("color", "red");
                                                                    gtag('event', 'FAVOURITES_ADD', {
                                                                        'event_category': 'FAVOURITES',
                                                                        'event_action': 'FAVOURITES_ADD_<?php echo e($product->id); ?>'
                                                                    });
                                                                } else {
                                                                    jQuery('#addtofav<?php echo e($product->id); ?>').css("color", "black");
                                                                    gtag('event', 'FAVOURITES_REMOVE', {
                                                                        'event_category': 'FAVOURITES',
                                                                        'event_action': 'FAVOURITES_REMOVE_<?php echo e($product->id); ?>'
                                                                    });
                                                                }

                                                            },
                                                            error: function (response) {
                                                                alert(response);

                                                            },

                                                        });
                                                    });
                                                });
                                            </script>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </div>
                                </div>
                                <?php echo e($pageproducts->setPath($item_group)->render()); ?>


                            </div>
                            <!-- Tab Content end -->

                        </div>
                    </div>
                    <?php
                    $crl2 = curl_init();

                    curl_setopt($crl2, CURLOPT_URL, 'http://163.172.33.245/goomla/api/categorytree');
                    curl_setopt($crl2, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($crl2, CURLOPT_SSL_VERIFYHOST, false);
                    curl_setopt($crl2, CURLOPT_SSL_VERIFYPEER, false);

                    $rest2 = curl_exec($crl2);
                    $categories = json_decode($rest2);
                    ?>
                    <style>
                        .custom-combobox {
                            position: relative;
                            display: inline-block;
                        }
                        .custom-combobox-toggle {
                            position: absolute;
                            top: 0;
                            bottom: 0;
                            margin-left: -1px;
                            padding: 0;
                        }
                        .custom-combobox-input {
                            margin: 0;
                            padding-top: 2px;
                            padding-bottom: 5px;
                            padding-right: 5px;
                        }
                        .ui-button .ui-icon
                        {
                            margin-top:6px;
                        }
                        .custom-combobox
                        {
                            width: 100%;
                        }
                        .custom-combobox .custom-combobox-input
                        {
                            width: 100%;
                            height: 30px;
                            background: none;
                        }
                    </style>

                    
                    <div class="col-md-3 col-xs-12">
                        <!-- widget-categories -->
                        <aside class="widget widget-categories box-shadow mb-30">
                            <h6 class="widget-title border-left mb-20" style="text-align: right;direction: rtl">
                                الاقسام</h6>
                            <div id="cat-treeview" class="product-cat">
                                <ul style="text-align: right;direction: rtl">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onecat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="closed">
                                            <a href="<?php echo e(url('products/'.$onecat->id)); ?>"><?php echo e($onecat->name); ?></a>
                                            <?php if($onecat->sub_categories != null ): ?>
                                                <ul>
                                                    <li>
                                                        <?php $__currentLoopData = $onecat->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <a href="<?php echo e(url('products/'.$subcats->id)); ?>"> <?php echo e($subcats->name); ?></a>
                                                            <br>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </li>
                                                </ul>
                                        <?php endif; ?>

                                        <!--level0-->
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </aside>
                        <aside class="widget shop-filter box-shadow mb-30">
                            <h6 class="widget-title border-left mb-20">السعر</h6>
                            <div class="price_filter">
                                <div class="price_slider_amount">
                                    <input value="You range :" type="submit">
                                    <input id="amount" name="price" placeholder="Add Your Price" type="text">
                                </div>
                                <div id="slider-range" class="ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all">
                                    <div class="ui-slider-range ui-widget-header ui-corner-all" style="left: 0%; width: 48.6667%;"></div>
                                    <span class="ui-slider-handle ui-state-default ui-corner-all" id="slider-left" tabindex="0" style="left: 0%;"></span>
                                    <span class="ui-slider-handle ui-state-default ui-corner-all" id="slider-right" tabindex="0" style="left: 48.6667%;"></span>
                                </div>
                            </div>
                        </aside>
                        <?php
                            $brands = Session::get('brand');
                        ?>
                        <aside class="widget shop-filter box-shadow mb-30">
                            <h6 class="widget-title border-left mb-20">الشركه المصنعة</h6>
                                    <div class="ui-widget">
                                        <select id="combobox">

                                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($key == 0): ?>

                                                    <option value="">-</option>
                                                    <option value="<?php echo e($brand); ?>"><?php echo e($brand); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($brand); ?>"><?php echo e($brand); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                        </aside>

                    </div>
                </div>
            </div>
        </div>
        <!-- SHOP SECTION END -->

    </section>
    <!-- End page content -->

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--style-customizer end -->
</div>
<!-- Body main wrapper end -->


<!-- Placed JS at the end of the document so the pages load faster -->
<script src="<?php echo e(asset('gomla/js/vendor/jquery-3.1.1.min.js')); ?>"></script>
<!-- Bootstrap framework js -->
<script src="<?php echo e(asset('gomla/js/bootstrap.min.js')); ?>"></script>
<!-- jquery.nivo.slider js -->
<script src="<?php echo e(asset('gomla/lib/js/jquery.nivo.slider.js')); ?>"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCDacJcoyPCr-jdlP9HK93h3YKNyf710J0"></script>
<script src="<?php echo e(asset('gomla/js/map.js')); ?>"></script>
<!-- All js plugins included in this file. -->
<script src="<?php echo e(asset('gomla/js/plugins.js')); ?>"></script>
<!-- Main js file that contents all jQuery plugins activation. -->
<script src="<?php echo e(asset('gomla/js/main.js')); ?>"></script>
<script>
    function view(title,price,img,desc){
        $('#productModal').modal('show');
        $("#modal_img").attr('src',img);
        $("#modal_desc").text(desc);
        $("#modal_header_title").text(title);
        $("#modelPrice").text(price + " " + "جنية ");
    }

</script>


<script type="text/javascript" src="<?php echo e(asset('js/parsley.js')); ?>"></script>
<script type="text/javascript">


    $('form').parsley();

    var loadingimg = "<?php echo e(asset('images/loading5.gif')); ?>";
    $('#register').one('click', function () {

        $('#loading-img').html('<img style="height:100px;" src="' + loadingimg + '" />');
//            jQuery('#loading-img').hide(10000);


        $('form').submit(function (e) {
            e.preventDefault(e);

            $.ajax({
                url: "<?php echo e(URL::to('register')); ?>",
                crossDomain: true,
                contentType: 'application/json',
                type: 'POST',
                data: JSON.stringify({
                    'name': $('input[name=name]').val(),
                    'email': $('input[name=UserEmail]').val(),
                    'phone': $('input[name=phone]').val(),
                    'address_phone': $('input[name=phone]').val(),
                    'password': $('input[name=UserPassword]').val(),
                    'floor_number': $('select[name=floor_number]').val(),
                    'apartment_number': $('input[name=apartment_number]').val(),
                    'building_number': $('input[name=building_number]').val(),
                    'street': $('input[name=street]').val(),
                    'nearest_landmark': $('input[name=nearest_landmark]').val(),
                    'region': $('select[name=region]').val(),
                    'city': "القاهره",
                    'lat': $('input[name=lat]').val(),
                    'lng': $('input[name=lng]').val(),
                    'address_title': $('input[name=address_title]').val(),
                    '_token': $('input[name=_token]').val()
                }),
                success: function (response) {
                    if (response == 1) {
                        $("#responseDone").html('<p>' + "تم التسجيل بنجاح" + '</p>');
                        window.scrollTo(0, 0);
                        $('.bs-example-modal-sm').modal('show');
                        $('#loading-img').hide();
                        window.setTimeout(function () {
                            window.location.href = '<?php echo e(url('/')); ?>';
                        }, 1000);

                    } else {

                        $("#responseDone").html('<p>' + response+ '</p>');
                        $("#responseDone p").css('color','red');
                        window.scrollTo(0, 0);

                        $('.bs-example-modal-sm').modal('show');
                        $('#loading-img').hide();
                    }


                },
                error: function (response) {
                    $("#responseDone").html('<p>' + response + '</p>');
                    $("#responseDone p").css('color','red');
                    window.scrollTo(0, 0);
                    $('.bs-example-modal-sm').modal('show');


                }
                ,
            });
        });
    })
    ;
</script>
<script>
    // Log LOGIN_NORMAL to Google Analytics
    var loginForm = document.getElementById('loginForm');
    loginForm.addEventListener('submit', function(event) {
        // Sends the event to Google Analytics
        gtag('event', 'LOGIN_NORMAL', {
            'event_category': 'LOGIN_SCREEN',
            'event_action': 'LOGIN_NORMAL'
        } )
    });

    // Log LOGIN_NORMAL to Google Analytics
    var facebookLogin = document.getElementById('Facebook');
    facebookLogin.addEventListener('click', function(event) {
        // Sends the event to Google Analytics
        gtag('event', 'LOGIN_FACEBOOK', {
            'event_category': 'LOGIN_SCREEN',
            'event_action': 'LOGIN_FACEBOOK'
        } )
    });
</script>
<script>
    // Log LOGIN_SKIP to Google Analytics
    var skipLogin = document.getElementById('homeSkipLoginBtn');
    skipLogin.addEventListener('click', function (event) {
        // Sends the event to Google Analytics
        gtag('event', 'LOGIN_SKIP', {
            'event_category': 'HOME_SCREEN',
            'event_action': 'LOGIN_SKIP'
        })
    });
</script>
<script>
    $( "#slider-range" ).slider({
        range: true,
        min: 5,
        max: 700,
        values: [ 5, 700 ],
        slide: function( event, ui ) {
            $( "#amount" ).val( "" + ui.values[ 0 ] + "-" + ui.values[ 1 ] );
        }
    });
    $( "#amount" ).val(  $( "#slider-range" ).slider( "values", 0 ) +
        "-" + $( "#slider-range" ).slider( "values", 1 ) );
    $("#slider-range").mouseleave(function(){
        $.ajax({
            type:'POST',
            url:'/price',
            data:{
                "_token": "<?php echo e(csrf_token()); ?>",
                'value':$( "#amount" ).val(),
                'cate': "<?php echo e(Request::url()); ?>",
                'brand':$(".custom-combobox-input").val()
            },
            success:function(data){
                $("#data").html(data.data);
            }
        });
    });
</script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>

<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
    $( function() {
        $.widget( "custom.combobox", {
            _create: function() {
                this.wrapper = $( "<span>" )
                    .addClass( "custom-combobox" )
                    .insertAfter( this.element );

                this.element.hide();
                this._createAutocomplete();
                this._createShowAllButton();
            },

            _createAutocomplete: function() {
                var selected = this.element.children( ":selected" ),
                    value = selected.val() ? selected.text() : "";

                this.input = $( "<input>" )
                    .appendTo( this.wrapper )
                    .val( value )
                    .attr( "title", "" )
                    .addClass( "custom-combobox-input ui-widget ui-widget-content ui-state-default ui-corner-left" )
                    .autocomplete({
                        delay: 0,
                        minLength: 0,
                        source: $.proxy( this, "_source" )
                    })
                    .tooltip({
                        classes: {
                            "ui-tooltip": "ui-state-highlight"
                        }
                    });

                this._on( this.input, {
                    autocompleteselect: function( event, ui ) {
                        ui.item.option.selected = true;
                        this._trigger( "select", event, {
                            item: ui.item.option
                        });
                    },

                    autocompletechange: "_removeIfInvalid"
                });
            },



            _source: function( request, response ) {
                var matcher = new RegExp( $.ui.autocomplete.escapeRegex(request.term), "i" );
                response( this.element.children( "option" ).map(function() {
                    var text = $( this ).text();
                    if ( this.value && ( !request.term || matcher.test(text) ) )
                        return {
                            label: text,
                            value: text,
                            option: this
                        };
                }) );
            },


            _destroy: function() {
                this.wrapper.remove();
                this.element.show();
            }
        });

        $( "#combobox" ).combobox();
        $( "#toggle" ).on( "click", function() {
            $( "#combobox" ).toggle();
        });
    } );

    $(".ui-widget").keyup(function(){
       var brand = $(".custom-combobox-input").val();
        $.ajax({
            type:'POST',
            url:'/brand',
            data:{
                "_token": "<?php echo e(csrf_token()); ?>",
                'value':$( "#amount" ).val(),
                'brand':brand,
                'cate': "<?php echo e(Request::url()); ?>"
            },
            success:function(data){
                $("#data").html(data.data);
            }
        });
    });
</script>
</body>

</html>

