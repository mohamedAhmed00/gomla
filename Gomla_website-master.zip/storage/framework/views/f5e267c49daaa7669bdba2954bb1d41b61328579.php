<aside class="col-left sidebar col-sm-3 col-xs-12 col-sm-pull-9 wow bounceInUp animated">
    <!-- BEGIN SIDE-NAV-CATEGORY -->
    <div class="side-nav-categories">
        <a href="<?php echo e(url('categories')); ?>">
            <div class="block-title">
                الأقسام
            </div>
        </a>
        <!--block-title-->
        <!-- BEGIN BOX-CATEGORY -->
        <div class="box-content box-category">
            <ul>

                <?php
                $crl2 = curl_init();

                curl_setopt($crl2, CURLOPT_URL, 'http://163.172.33.245/goomla/api/categorytree');
                curl_setopt($crl2, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($crl2, CURLOPT_SSL_VERIFYHOST, false);
                curl_setopt($crl2, CURLOPT_SSL_VERIFYPEER, false);

                $rest2 = curl_exec($crl2);
                $categories = json_decode($rest2);
                ?>


                

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onecat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <li>
                            <a class="" href="<?php echo e(url('products/'.$onecat->id)); ?>"><?php echo e($onecat->name); ?></a>
                            <span class="subDropdown minus"></span>


                            <?php if($onecat->sub_categories != null ): ?>
                            <ul class="level0_415" style="display:block">
                                <!--level1-->

                                <li>
                                    <?php $__currentLoopData = $onecat->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(url('products/'.$subcats->id)); ?>"> <?php echo e($subcats->name); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </li>
                            </ul>
                        <?php endif; ?>

                        <!--level0-->
                        </li>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        

            </ul>
        </div>
        <!--box-content box-category-->
    </div>
    <!--side-nav-categories-->


</aside>