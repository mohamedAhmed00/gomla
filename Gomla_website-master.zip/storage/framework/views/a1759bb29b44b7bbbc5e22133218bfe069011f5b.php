<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Body main wrapper start -->
<div class="wrapper">
    <!-- START HEADER AREA -->
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- BREADCRUMBS SETCTION START -->
    <div class="breadcrumbs-section plr-200 mb-80">
        <div class="breadcrumbs overlay-bg" style="background: #f6f6f6 url('http://163.172.33.245/goomla/storage/app/erpnext/<?php echo e($catimg['images'][0]); ?>') no-repeat scroll center center;background-size: 100% 100%;height: 500px">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="breadcrumbs-inner">
                            <h1 class="breadcrumbs-title" style="color:#000;padding-top: 215px;font-family: 'Amiri', serif"><?php echo e($catimg['name']); ?></h1>
                            <ul class="breadcrumb-list">

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- BREADCRUMBS SETCTION END -->

    <!-- Start page content -->
    <section id="page-content" class="page-wrapper">

        <!-- SHOP SECTION START -->
        <div class="shop-section mb-80">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 col-xs-12">
                        <div class="shop-content">
                            <!-- Tab Content start -->
                            <div class="tab-content">
                                <!-- grid-view -->
                                <div role="tabpanel" class="tab-pane active" id="grid-view">
                                    <div class="row">
                                        <!-- product-item start -->
                                        <?php $__currentLoopData = $sub_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <div class="product-item">
                                                    <div class="product-img">
                                                        <a href="<?php echo e(url('products/'.$category['id'])); ?>">
                                                            <?php if(isset($category['images'])): ?>
                                                                <img style="height: 350px;width: 100%;"  src="http://163.172.33.245/goomla/storage/app/erpnext/<?php echo e($category['images'][0]); ?>" alt="<?php echo e($category['name']); ?>">
                                                            <?php else: ?>
                                                                <img style="height: 350px;width: 100%;" src="<?php echo e(asset('gomla/images/blog-banner.png')); ?>" alt="<?php echo e($category['name']); ?>">
                                                            <?php endif; ?>
                                                        </a>
                                                    </div>
                                                    <div class="product-info">
                                                        <h6 class="product-title"><a href="<?php echo e(url('products/'.$category['id'])); ?>" title="<?php echo e($category['name']); ?>"><?php echo e($category['name']); ?></a></h6>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                            </div>
                            <!-- Tab Content end -->

                        </div>
                    </div>
                    <?php
                    $crl2 = curl_init();

                    curl_setopt($crl2, CURLOPT_URL, 'http://163.172.33.245/goomla/api/categorytree');
                    curl_setopt($crl2, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($crl2, CURLOPT_SSL_VERIFYHOST, false);
                    curl_setopt($crl2, CURLOPT_SSL_VERIFYPEER, false);

                    $rest2 = curl_exec($crl2);
                    $categories = json_decode($rest2);
                    ?>


                    
                    <div class="col-md-3 col-xs-12">
                        <!-- widget-categories -->
                        <aside class="widget widget-categories box-shadow mb-30">
                            <h6 class="widget-title border-left mb-20" style="text-align: right;direction: rtl">الاقسام</h6>
                            <div id="cat-treeview" class="product-cat">
                                <ul style="text-align: right;direction: rtl">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onecat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="closed">
                                            <a  href="<?php echo e(url('products/'.$onecat->id)); ?>"><?php echo e($onecat->name); ?></a>
                                            <?php if($onecat->sub_categories != null ): ?>
                                                <ul>
                                                    <li>
                                                        <?php $__currentLoopData = $onecat->sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <a href="<?php echo e(url('products/'.$subcats->id)); ?>"> <?php echo e($subcats->name); ?></a>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </li>
                                                </ul>
                                        <?php endif; ?>

                                        <!--level0-->
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </aside>

                    </div>
                </div>
            </div>
        </div>
        <!-- SHOP SECTION END -->

    </section>
    <!-- End page content -->

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--style-customizer end -->
</div>
<!-- Body main wrapper end -->


<!-- Placed JS at the end of the document so the pages load faster -->
<?php echo $__env->make('layouts.endpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>