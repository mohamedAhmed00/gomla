Name : {{ $name }}
<br>
<br>
<br>

Email: {{ $email }}
<br>
<br>
<br>


Phone: {{ $phone }}
<br>
<br>
<br>

message: {{ $msg }}
<br>
<br>
<br>
